# Real City + Snap AI server

`public/index.html` is your game. `server.js` hosts it and gives **Snap AI** a brain, so it can answer any question.

## 1. Run it on your computer
1. Install Node.js 18 or newer.
2. Get an API key at https://console.anthropic.com (keep it secret, never paste it into the game file).
3. In this folder:
   ```
   export ANTHROPIC_API_KEY=sk-ant-...      # Windows PowerShell:  $env:ANTHROPIC_API_KEY="sk-ant-..."
   npm start
   ```
4. Open http://localhost:3000, press P for the phone, open Snap, then chat with **Snap AI**.
   If you see "offline mode", open http://localhost:3000/api/health - `"ai":true` means the key is loaded.

## 2. Put it online (so friends can use it)
Any Node host works (Render, Railway, Fly.io). On Render: New > Web Service > upload this folder,
Build command: *(empty)*, Start command: `npm start`, then add the environment variable `ANTHROPIC_API_KEY`.
Open the URL Render gives you. Snap AI works automatically because the game and the AI share the same address.

## 3. Game hosted somewhere else?
If `index.html` lives on a different site, tell the game where the server is, either:
- type the server address in the "Game + Snap AI server" box on the start screen, or
- add `<script>window.RC_AI_URL='https://your-server.onrender.com'</script>` above the main script in `index.html`.
Set `ALLOWED_ORIGIN` on the server to your game's address so nobody else can use your key.

## Settings (environment variables)
| Name | What it does | Default |
|---|---|---|
| `ANTHROPIC_API_KEY` | turns Snap AI on | none |
| `SNAP_AI_MODEL` | `claude-haiku-5-5` is fast and cheap, `claude-sonnet-5-5` is smarter | haiku |
| `SNAP_AI_WEB_SEARCH` | `1` lets Snap AI look things up online | off |
| `SNAP_AI_PER_MIN` | messages per player per minute | 12 |
| `SNAP_AI_MAX_PER_DAY` | hard daily cap on your bill | 3000 |

## Not included
This server does **not** run the live multiplayer (players seeing each other). Your game's multiplayer code talks to a
separate websocket server that was not in the file you sent.
