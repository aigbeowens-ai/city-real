'use strict';
/**
 * Real City server
 *  - serves the game from ./public
 *  - POST /api/snap-ai  -> Snap AI answers any question using the Anthropic API
 *  - GET  /api/health   -> quick status check
 *
 * No npm packages needed (Node 18+).
 */
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = parseInt(process.env.PORT, 10) || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY || '';
const MODEL = process.env.SNAP_AI_MODEL || 'claude-haiku-5-5';
const API_BASE = (process.env.ANTHROPIC_API_URL || 'https://api.anthropic.com').replace(/\/+$/, '');
const ALLOW_ORIGIN = process.env.ALLOWED_ORIGIN || '*';          // set to your game's URL to lock it down
const WEB_SEARCH = process.env.SNAP_AI_WEB_SEARCH === '1';        // let Snap AI look things up online
const PER_IP_PER_MIN = parseInt(process.env.SNAP_AI_PER_MIN, 10) || 12;
const MAX_PER_DAY = parseInt(process.env.SNAP_AI_MAX_PER_DAY, 10) || 3000; // hard cap on your bill
const PUBLIC_DIR = path.join(__dirname, 'public');

const SYSTEM = [
  'You are Snap AI, the friendly assistant inside the phone of a 3D open-world game called Real City.',
  'You can answer ANY question: school help, maths, science, coding, advice, facts, ideas, jokes, stories, translations.',
  'Style: short, warm and clear. Plain text only - no markdown, no asterisks, no headings, no bullet symbols.',
  'Use at most a couple of emojis. Keep most answers under 600 characters; go longer only if the person clearly needs it.',
  'If you are not sure about something, say so instead of guessing. Never invent facts, links or quotes.',
  'Many players are teenagers: stay kind and safe. Do not give help that could seriously hurt people (weapons, self-harm methods, hacking others). Offer a safer alternative instead.',
  'Real City tips you can share: move with W A S D, run with Shift, E enters or exits cars, E sits on chairs and benches, C changes camera, P opens the phone, H shows help. Walk up to a house to claim it. The phone has Snap (chat, camera, lenses), Games, Family and more.',
].join('\n');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.txt': 'text/plain; charset=utf-8',
};

// ---------- tiny rate limiter ----------
const hits = new Map();
let dayKey = '', dayCount = 0;
function allowed(ip) {
  const today = new Date().toISOString().slice(0, 10);
  if (today !== dayKey) { dayKey = today; dayCount = 0; }
  if (dayCount >= MAX_PER_DAY) return 'The daily AI limit was reached. Try again tomorrow!';
  const now = Date.now(), arr = (hits.get(ip) || []).filter(t => now - t < 60000);
  if (arr.length >= PER_IP_PER_MIN) return 'Slow down a little - you are sending too many messages.';
  arr.push(now); hits.set(ip, arr); dayCount++;
  return '';
}
setInterval(() => { const now = Date.now(); for (const [ip, a] of hits) if (!a.some(t => now - t < 60000)) hits.delete(ip); }, 60000).unref();

// ---------- helpers ----------
function cors(res) {
  res.setHeader('Access-Control-Allow-Origin', ALLOW_ORIGIN);
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Max-Age', '86400');
}
function sendJson(res, code, obj) {
  cors(res);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new Error('too big')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function clientIp(req) {
  const xf = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
  return xf || req.socket.remoteAddress || 'unknown';
}
// turn whatever the game sent into a clean alternating user/assistant list that starts and ends with "user"
function cleanMessages(list) {
  const out = [];
  for (const m of Array.isArray(list) ? list.slice(-14) : []) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant')) continue;
    const text = String(m.content == null ? '' : m.content).replace(/\s+/g, ' ').trim().slice(0, 600);
    if (!text) continue;
    if (out.length && out[out.length - 1].role === m.role) out[out.length - 1].content += '\n' + text;
    else out.push({ role: m.role, content: text });
  }
  while (out.length && out[0].role !== 'user') out.shift();
  while (out.length && out[out.length - 1].role !== 'user') out.pop();
  return out;
}

async function askClaude(messages, name, time) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 20000);
  try {
    const body = {
      model: MODEL,
      max_tokens: 500,
      system: SYSTEM + '\nThe player is called ' + String(name || 'a player').slice(0, 24).replace(/[^\w \-]/g, '') +
        (time ? '. Game clock: ' + String(time).slice(0, 12) : '') + '. Today is ' + new Date().toDateString() + '.',
      messages,
    };
    if (WEB_SEARCH) body.tools = [{ type: 'web_search_20250305', name: 'web_search', max_uses: 3 }];
    const r = await fetch(API_BASE + '/v1/messages', {
      method: 'POST',
      headers: { 'content-type': 'application/json', 'x-api-key': API_KEY, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify(body),
      signal: ctl.signal,
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) {
      console.error('Anthropic API error', r.status, j && j.error && j.error.message);
      const e = new Error('upstream ' + r.status); e.status = r.status; throw e;
    }
    const text = (j.content || []).filter(b => b && b.type === 'text').map(b => b.text).join('').replace(/\*\*/g, '').trim();
    if (!text) throw new Error('empty reply');
    return text.slice(0, 1400);
  } finally { clearTimeout(timer); }
}

// ---------- routes ----------
async function handleAi(req, res) {
  if (!API_KEY) return sendJson(res, 503, { error: 'AI is not configured: set ANTHROPIC_API_KEY on the server.' });
  const ip = clientIp(req), block = allowed(ip);
  if (block) return sendJson(res, 429, { error: block });
  let data;
  try { data = JSON.parse(await readBody(req, 32 * 1024)); } catch (e) { return sendJson(res, 400, { error: 'Bad request.' }); }
  const messages = cleanMessages(data && data.messages);
  if (!messages.length) return sendJson(res, 400, { error: 'No question was sent.' });
  try {
    const reply = await askClaude(messages, data.name, data.time);
    sendJson(res, 200, { reply });
  } catch (e) {
    const busy = e && e.status === 429;
    sendJson(res, busy ? 429 : 502, { error: busy ? 'Snap AI is busy, try again in a moment.' : 'Snap AI could not answer right now.' });
  }
}

function serveStatic(req, res) {
  let p = decodeURIComponent((req.url || '/').split('?')[0]);
  if (p === '/' || p === '') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC_DIR, p));
  if (!file.startsWith(PUBLIC_DIR)) { res.writeHead(403); return res.end('Forbidden'); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(buf);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = (req.url || '').split('?')[0];
    if (req.method === 'OPTIONS') { cors(res); res.writeHead(204); return res.end(); }
    if (url === '/api/snap-ai' && req.method === 'POST') return await handleAi(req, res);
    if (url === '/api/health') return sendJson(res, 200, { ok: true, ai: !!API_KEY, model: MODEL, webSearch: WEB_SEARCH });
    if (req.method === 'GET' || req.method === 'HEAD') return serveStatic(req, res);
    res.writeHead(405); res.end();
  } catch (e) { console.error(e); if (!res.headersSent) sendJson(res, 500, { error: 'Server error.' }); }
});
server.listen(PORT, () => {
  console.log('Real City server on http://localhost:' + PORT);
  console.log(API_KEY ? 'Snap AI: ONLINE (model ' + MODEL + ')' : 'Snap AI: OFFLINE - set ANTHROPIC_API_KEY to turn it on');
});
